a = [10, 1, 2, 76, 20, 3, 20, 49, 98, 5]
n = 0
for i in a:
    if i > 5:
        print i
    else:
        n += 1

print "n is " + str(n)